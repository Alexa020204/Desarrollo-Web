export default interface PeliculasInterfaces{
    image: string
    title: string
}