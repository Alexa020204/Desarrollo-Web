export default class IndexModel{
    constructor (){
        console.log('IndexModel')
    }

    public getData(): void{
        console.log('IndexModel.getData')
    }
    
}