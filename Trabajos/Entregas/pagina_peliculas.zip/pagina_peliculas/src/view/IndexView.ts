export default class IndexView{
    constructor (){
        console.log('IndexView')
    }
    public deploy (): void {
        console.log('IndexView.display')
    }
    
}