npm init -y
npm i typescript //instala javascript
npm i ts-standard -D //Dependencias desarrollo
tsc --init //arranca el archivo de configuración de tyscrip
