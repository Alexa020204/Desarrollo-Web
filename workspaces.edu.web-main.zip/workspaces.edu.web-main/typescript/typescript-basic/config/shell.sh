# config windows on power shell admin
Set-ExecutionPolicy Unrestricted
# install typescript
npm install -g typescript
tsc -v
# run
npx tsc -w