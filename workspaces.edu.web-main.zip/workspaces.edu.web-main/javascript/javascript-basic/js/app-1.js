/* comentario 
múltiples 
líneas  */

// comentario 1 línea

alert('Hola mundo');

const nombre = prompt('¿nombre?');

document.querySelector('.disp').innerHTML = `hola ${nombre}!!!`;

alert('console log');

console.log([1,2,3,4,5]);

alert('console table');

console.table([1,2,3,4,5]);

alert('console error');

console.error("un error");

alert('console warning');

console.warn("una advertencia");

alert('console clear');

console.clear();

alert('console time');

console.time("time");

console.warn("contando...");
console.warn("contando...");
console.warn("contando...");
console.warn("contando...");
console.warn("contando...");
console.warn("contando...");
console.warn("contando...");
console.warn("contando...");
console.warn("contando...");
console.warn("contando...");

console.timeEnd("time");